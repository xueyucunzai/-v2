import { ECO_ID, SEED_OBJECTS, SEED_RELS } from './data.js';

/* ===================== 基础：错误记录 / 工具 ===================== */
const errLog = [];
addEventListener('error', (e) => errLog.push(String(e.message || e.error)));
addEventListener('unhandledrejection', (e) => errLog.push('Promise: ' + String((e.reason && e.reason.message) || e.reason)));

const esc = (t) => String(t ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]);
const link = (u, l) => (/^https:\/\//.test(u || '') ? `<a href="${esc(u)}" target="_blank" rel="noopener noreferrer">${esc(l || u)}</a>` : esc(l || u || ''));
const cap = (s) => { s = String(s || ''); return s.charAt(0).toUpperCase() + s.slice(1); };
const fmtTime = (t) => (t ? new Date(t).toLocaleString('zh-CN', { hour12: false }) : '未提供');
const NA = '<span class="muted">暂无数据</span>';

function fmtVal(v, unit) {
  if (v === null || v === undefined || Number.isNaN(v)) return null;
  if (unit === 'usd') {
    const a = Math.abs(v);
    if (a >= 1e9) return '$' + (v / 1e9).toFixed(3) + 'B';
    if (a >= 1e6) return '$' + (v / 1e6).toFixed(2) + 'M';
    if (a >= 1000) return '$' + Math.round(v).toLocaleString('en-US');
    if (a >= 1) return '$' + v.toFixed(4).replace(/0+$/, '').replace(/\.$/, '');
    return '$' + Number(v.toPrecision(4)).toString();
  }
  if (unit === 'pct') return (v >= 0 ? '+' : '') + v.toFixed(2) + '%';
  if (unit === 'num') return Number(v).toLocaleString('en-US', { maximumFractionDigits: 2 });
  return String(v);
}

/* ===================== IndexedDB（沿用 v4 的库名与 store，数据不丢） ===================== */
const DB_NAME = 'crypto-ecosystem-research';
const STORES = ['objects', 'relationships', 'sources', 'metrics', 'data_records', 'research', 'branches', 'observations', 'hypotheses', 'evidence', 'findings', 'snapshots', 'events', 'settings', 'self_check_runs', 'ai_action_logs'];
let dbp;
const db = () => dbp || (dbp = new Promise((res, rej) => {
  const r = indexedDB.open(DB_NAME, 1);
  r.onupgradeneeded = () => { for (const s of STORES) if (!r.result.objectStoreNames.contains(s)) r.result.createObjectStore(s, { keyPath: 'id' }); };
  r.onsuccess = () => res(r.result);
  r.onerror = () => rej(r.error);
}));
const tx = async (store, mode, fn) => {
  const d = await db();
  return new Promise((res, rej) => {
    const t = d.transaction(store, mode);
    const rq = fn(t.objectStore(store));
    t.oncomplete = () => res(rq && rq.result);
    t.onerror = () => rej(t.error);
    t.onabort = () => rej(t.error);
  });
};
/* ===================== V2 云端数据层（Pages Functions / Workers + D1） =====================
   云端可用时：D1 为主；云端不可用时：自动回退 IndexedDB。
   这样旧的本地研究数据不会因为后端暂时不可用而消失。
*/
let cloudReady = false;
let cloudInitP = null;

const localGetAll = (s) => tx(s, 'readonly', (o) => o.getAll());
const localGet = (s, id) => tx(s, 'readonly', (o) => o.get(id));
const localPut = (s, v) => tx(s, 'readwrite', (o) => o.put(v));

async function cloudRequest(path, options = {}) {
  const r = await fetch('/api' + path, {
    cache: 'no-store',
    ...options,
    headers: { 'Content-Type': 'application/json', ...(options.headers || {}) }
  });
  if (!r.ok) throw new Error('API HTTP ' + r.status);
  return r.json();
}

async function initCloud() {
  if (cloudInitP) return cloudInitP;
  cloudInitP = (async () => {
    try {
      const h = await cloudRequest('/health');
      if (!h || h.ok !== true || h.version !== 'v2') return false;
      // 首次切换到 V2 时，把旧 IndexedDB 数据一次性迁移到 D1。
      const migrated = await localGet('settings', 'v2:cloud-migrated').catch(() => null);
      if (!migrated) {
        const stores = {};
        for (const s of STORES) {
          stores[s] = await localGetAll(s).catch(() => []);
        }
        await cloudRequest('/migrate', { method: 'POST', body: JSON.stringify({ stores }) });
        await localPut('settings', { id: 'v2:cloud-migrated', value: { at: Date.now(), version: 'v2' } }).catch(() => {});
      }
      return true;
    } catch (e) {
      return false;
    }
  })();
  cloudReady = await cloudInitP;
  return cloudReady;
}

const getAll = async (s) => {
  await initCloud();
  if (cloudReady) {
    try { const r = await cloudRequest('/store/' + encodeURIComponent(s)); return Array.isArray(r.items) ? r.items : []; }
    catch (e) { cloudReady = false; }
  }
  return localGetAll(s);
};
const get = async (s, id) => {
  await initCloud();
  if (cloudReady) {
    try { const r = await cloudRequest('/store/' + encodeURIComponent(s) + '/' + encodeURIComponent(id)); return r.item || null; }
    catch (e) { cloudReady = false; }
  }
  return localGet(s, id);
};
const put = async (s, v) => {
  await initCloud();
  if (cloudReady) {
    try { await cloudRequest('/store/' + encodeURIComponent(s), { method: 'PUT', body: JSON.stringify({ item: v }) }); }
    catch (e) { cloudReady = false; }
  }
  return localPut(s, v);
};
const getSetting = async (k) => { try { const r = await get('settings', k); return r ? r.value : null; } catch { return null; } };
const setSetting = (k, v) => put('settings', { id: k, value: v }).catch(() => {});
const cloudStatus = () => cloudReady;

async function seed() {
  // 身份种子是“权威身份层”，每次启动都做一次幂等同步：
  // 保留运行期字段，同时用种子修正名称、Symbol、Chain、Contract、CoinGecko ID、官方来源等身份字段。
  for (const o of SEED_OBJECTS) {
    const prev = await get('objects', o.id).catch(() => null);
    if (!prev) {
      await put('objects', o);
      continue;
    }
    const merged = { ...prev, ...o };
    // 身份字段由种子修正；运行期解析状态与缓存身份结果保留，下一次刷新会重新验证。
    for (const k of ['identityStatus', 'identitySource']) {
      if (prev[k] !== undefined) merged[k] = prev[k];
    }
    await put('objects', merged);
  }
  for (const r of SEED_RELS) { if (!(await get('relationships', r.id))) await put('relationships', r); }
}
const seeded = seed().catch((e) => errLog.push('seed: ' + e));

async function loadGraph() {
  await seeded;
  const objs = await getAll('objects').catch(() => []);
  const rels = await getAll('relationships').catch(() => []);
  return { objs, rels, byId: Object.fromEntries(objs.map((o) => [o.id, o])) };
}
async function metricsFor(id) {
  const all = await getAll('metrics').catch(() => []);
  return Object.fromEntries(all.filter((m) => m.objectId === id).map((m) => [m.key, m]));
}

/* ===================== 数据状态 ===================== */
const STALE_MS = 24 * 3600 * 1000;
function effStatus(m) {
  if (!m) return 'NO_DATA';
  if (m.status === 'AVAILABLE') {
    if (m.retrievedAt && Date.now() - m.retrievedAt > STALE_MS) return 'STALE';
    if (m.sourceUpdatedAt && Date.now() - m.sourceUpdatedAt > 3 * STALE_MS) return 'STALE';
  }
  return m.status || 'NO_DATA';
}
const tagS = (s) => `<span class="tag ${String(s).toLowerCase()}">${esc(s)}</span>`;

/* ===================== 数据源请求（带缓存，失败不崩溃） ===================== */
async function fetchJSON(url, { ttl = 10 * 60 * 1000, reduce } = {}) {
  const key = 'cache:' + url;
  let c = null;
  try { c = await get('settings', key); } catch { /* ignore */ }
  if (c && Date.now() - c.t < ttl) return { data: c.data, t: c.t, cached: true };
  try {
    const ctl = new AbortController();
    const to = setTimeout(() => ctl.abort(), 25000);
    // V2：后端可用时统一通过 Worker/Pages Function 代理公开数据源。
    // 后端不可用时才直接访问原始 API，保证研究流程不中断。
    const requestUrl = cloudReady ? '/api/proxy?url=' + encodeURIComponent(url) : url;
    const r = await fetch(requestUrl, { signal: ctl.signal, cache: 'no-store' });
    clearTimeout(to);
    if (!r.ok) throw new Error('HTTP ' + r.status + (r.status === 429 ? '（请求过于频繁，稍后再试）' : ''));
    let d = await r.json();
    if (reduce) d = reduce(d);
    const t = Date.now();
    try { await put('settings', { id: key, t, data: d }); } catch { /* 缓存失败不影响使用 */ }
    return { data: d, t, cached: false };
  } catch (e) {
    return { error: String((e && e.message) || e), lastT: c ? c.t : null };
  }
}

async function saveMetric(objectId, key, f) {
  const id = objectId + '|' + key;
  const prev = await get('metrics', id).catch(() => null);
  let rec = { id, objectId, key, ...f };
  if (f.status === 'ERROR' && prev) {
    rec = { ...prev, ...f, id, objectId, key, status: 'ERROR', lastSuccessAt: (prev.status === 'AVAILABLE' || prev.status === 'STALE') ? prev.retrievedAt : prev.lastSuccessAt };
  }
  await put('metrics', rec);
}

/* ===================== 指标定义（中文解释） ===================== */
const ML = {
  chain_tvl: 'TVL（Total Value Locked，锁仓总价值）',
  tvl_30d_change: 'TVL 近 30 天变化（计算值）',
  stablecoin_supply: 'Stablecoin Supply（稳定币链上流通量，美元锚定）',
  dex_volume_24h: 'DEX Volume 24h（去中心化交易所 24 小时成交量）',
  dex_volume_30d: 'DEX Volume 30d（30 天成交量）',
  fees_24h: 'Fees 24h（协议产生的费用）',
  revenue_24h: 'Revenue 24h（协议实际收入，DeFiLlama 口径）',
  users: 'Users（用户 / 地址统计，口径需注明；不等于真实人数）',
  tvl: 'TVL（锁仓总价值）',
  price: 'Price（价格）',
  market_cap: 'Market Cap（市值）',
  fdv: 'FDV（Fully Diluted Valuation，完全稀释估值）',
  volume_24h: 'Volume 24h（代币 24 小时成交量）',
  total_supply: 'Total Supply（总供应量）',
  circulating_supply: 'Circulating Supply（流通供应量）',
  ath: 'ATH（历史最高价）',
  atl: 'ATL（历史最低价）',
  unlock_amount: 'Unlock Amount（解锁总量）',
  unlocked_amount: 'Unlocked Amount（已解锁量）',
  next_unlock: 'Next Unlock（下次解锁）',
};
const ECO_KEYS = ['chain_tvl', 'tvl_30d_change', 'stablecoin_supply', 'dex_volume_24h', 'dex_volume_30d', 'fees_24h', 'revenue_24h', 'users'];
const PROTO_KEYS = ['tvl', 'dex_volume_24h', 'fees_24h', 'revenue_24h', 'users'];
const TOKEN_KEYS = ['price', 'market_cap', 'fdv', 'volume_24h', 'total_supply', 'circulating_supply', 'ath', 'atl', 'unlock_amount', 'unlocked_amount', 'next_unlock'];

const LL = 'https://api.llama.fi';
const SL = 'https://stablecoins.llama.fi';
const CG = 'https://api.coingecko.com/api/v3';
const geckoIdFor = (o) => o.gecko_id || (o.id === ECO_ID ? 'solana' : null);
const tokenForProtocol = (protocolId, rels, byId) => {
  const r = (rels || []).find((x) => x.from === protocolId && x.type === 'associated_token' && byId[x.to]);
  return r ? byId[r.to] : null;
};
const tokenIdentityNote = (t) => t && t.identityStatus === 'AMBIGUOUS' ? '存在多个候选 Token，需要确认' : t && t.identityStatus === 'NOT_FOUND' ? 'Token Identity 尚未确认' : '';

/* Token Identity：Protocol 与 Token 完全分离。Chain + Contract 优先；没有 Contract 时才用 Symbol/Name 候选匹配。 */
async function resolveTokenIdentity(t) {
  if (!t || t.type !== 'token') return t;
  if (t.chain && t.contractAddress) {
    const r = await fetchJSON(`${CG}/coins/${encodeURIComponent(t.chain)}/contract/${encodeURIComponent(t.contractAddress)}`, { ttl: 5 * 60 * 1000 });
    if (!r.error && r.data && r.data.id) {
      const symbol = String(r.data.symbol || t.symbol || '').toUpperCase();
      const name = r.data.name || t.name;
      t.gecko_id = r.data.id; t.symbol = symbol; t.name = name; t.identityStatus = 'CONFIRMED';
      t.identitySource = 'Contract + Chain → CoinGecko';
      await put('objects', t);
      return t;
    }
    t.identityStatus = 'NOT_FOUND';
    t.identitySource = 'Contract + Chain → CoinGecko 未确认';
    await put('objects', t);
    return t;
  }
  if (t.gecko_id) {
    t.identityStatus = 'CONFIRMED';
    t.identitySource = t.identitySource || 'CoinGecko ID';
    await put('objects', t);
    return t;
  }
  const q = t.symbol || t.name;
  if (!q) { t.identityStatus = 'NOT_FOUND'; await put('objects', t); return t; }
  const r = await fetchJSON(`${CG}/search?query=${encodeURIComponent(q)}`, { ttl: 30 * 60 * 1000 });
  const coins = !r.error && r.data && Array.isArray(r.data.coins) ? r.data.coins : [];
  const sym = String(t.symbol || '').toUpperCase();
  const exact = coins.filter((c) => String(c.symbol || '').toUpperCase() === sym && (!t.name || String(c.name || '').toLowerCase() === String(t.name).toLowerCase()));
  if (exact.length === 1) {
    t.gecko_id = exact[0].id; t.identityStatus = 'CONFIRMED'; t.identitySource = 'Symbol + Name → CoinGecko unique candidate';
  } else if (exact.length > 1) {
    t.identityStatus = 'AMBIGUOUS'; t.identitySource = 'Symbol + Name → CoinGecko multiple candidates';
  } else {
    t.identityStatus = 'NOT_FOUND'; t.identitySource = 'Symbol + Name → CoinGecko 未确认';
  }
  await put('objects', t);
  return t;
}

// Shared metric helpers: must be available to both ecosystem/protocol refresh and Token refresh.
const metricNow = (r) => r && r.t ? r.t : Date.now();
const metricError = (r) => ({ status: 'ERROR', error: r && r.error ? r.error : 'Unknown error', retrievedAt: Date.now() });
const metricBase = (src, url, r, extra) => ({ status: 'AVAILABLE', source: src, sourceUrl: url, retrievedAt: metricNow(r), sourceUpdatedAt: null, ...extra });
const metricNoData = (note, src) => ({ status: 'NO_DATA', source: src || '', note, retrievedAt: Date.now() });

async function refreshTokenMarketData(t, say) {
  if (!t || t.type !== 'token') return;
  say && say(`刷新 Token ${t.symbol || t.name}…`);
  const identity = await resolveTokenIdentity(t);
  const gid = identity && identity.gecko_id;
  const fields = [['price', 'current_price', 'usd'], ['market_cap', 'market_cap', 'usd'], ['fdv', 'fully_diluted_valuation', 'usd'], ['volume_24h', 'total_volume', 'usd'], ['total_supply', 'total_supply', 'num'], ['circulating_supply', 'circulating_supply', 'num'], ['ath', 'ath', 'usd'], ['atl', 'atl', 'usd']];
  if (!gid) {
    const note = tokenIdentityNote(identity) || 'Token Identity 尚未确认';
    for (const [k, , unit] of fields) await saveMetric(t.id, k, { ...metricNoData(note, 'Token Identity'), unit });
  } else {
    const mk = await fetchJSON(`${CG}/coins/markets?vs_currency=usd&ids=${encodeURIComponent(gid)}&per_page=1&sparkline=false`, { ttl: 5 * 60 * 1000 });
    const m = mk.error ? null : (mk.data || [])[0];
    for (const [k, f, unit] of fields) {
      if (mk.error) await saveMetric(t.id, k, { ...metricError(mk), source: 'CoinGecko /coins/markets', sourceUrl: 'https://www.coingecko.com/en/coins/' + gid, unit });
      else if (!m) await saveMetric(t.id, k, { ...metricNoData('CoinGecko 未返回该资产', 'CoinGecko'), unit, sourceUrl: 'https://www.coingecko.com/en/coins/' + gid });
      else if (typeof m[f] !== 'number') await saveMetric(t.id, k, { ...metricNoData('CoinGecko 未提供该字段', 'CoinGecko'), unit, sourceUrl: 'https://www.coingecko.com/en/coins/' + gid });
      else await saveMetric(t.id, k, metricBase('CoinGecko /coins/markets', 'https://www.coingecko.com/en/coins/' + gid, mk, { value: m[f], unit, sourceUpdatedAt: m.last_updated ? Date.parse(m.last_updated) : null, definition: 'Token Identity：' + gid }));
    }
  }
  for (const k of ['unlock_amount', 'unlocked_amount', 'next_unlock']) await saveMetric(t.id, k, { ...metricNoData('CoinGecko 免费接口不提供解锁数据；不估算', 'CoinGecko'), unit: k === 'next_unlock' ? 'text' : 'num' });
}

/* ===================== 刷新数据（DeFiLlama + CoinGecko，均为免费无 Key 接口） ===================== */
async function refreshAll(progress) {
  const say = (t) => progress && progress(t);
  say('请求 DeFiLlama / CoinGecko…');
  const q = '?excludeTotalDataChart=true&excludeTotalDataChartBreakdown=true';
  const [chains, hist, stable, dex, fees, rev, prots] = await Promise.all([
    fetchJSON(LL + '/v2/chains'),
    fetchJSON(LL + '/v2/historicalChainTvl/Solana', { reduce: (a) => (Array.isArray(a) ? a.slice(-31) : []) }),
    fetchJSON(SL + '/stablecoinchains'),
    fetchJSON(LL + '/overview/dexs/solana' + q),
    fetchJSON(LL + '/overview/fees/solana' + q),
    fetchJSON(LL + '/overview/fees/solana' + q + '&dataType=dailyRevenue'),
    fetchJSON(LL + '/protocols', {
      ttl: 6 * 3600 * 1000,
      reduce: (a) => (Array.isArray(a) ? a.filter((p) => (p.chains || []).includes('Solana')).map((p) => ({
        name: p.name, slug: p.slug, symbol: p.symbol, gecko_id: p.gecko_id, category: p.category,
        tvl: p.chainTvls && typeof p.chainTvls.Solana === 'number' ? p.chainTvls.Solana : null,
        tvlAll: typeof p.tvl === 'number' ? p.tvl : null,
      })) : []),
    }),
  ]);

  const now = metricNow;
  const E = metricError;
  const base = metricBase;
  const nodata = metricNoData;

  // —— 生态层 ——
  const eco = ECO_ID;
  const put1 = (k, f) => saveMetric(eco, k, f);
  // TVL：A = /v2/chains（当前值），B = historicalChainTvl（日线最后一个点）
  if (chains.error) await put1('chain_tvl', { ...E(chains), source: 'DeFiLlama /v2/chains', sourceUrl: 'https://defillama.com/chain/Solana', unit: 'usd' });
  else {
    const c = chains.data.find((x) => x.name === 'Solana');
    if (!c || typeof c.tvl !== 'number') await put1('chain_tvl', { ...nodata('DeFiLlama 未返回 Solana 的 TVL', 'DeFiLlama'), unit: 'usd' });
    else {
      const alts = [];
      if (!hist.error && hist.data.length) {
        const last = hist.data[hist.data.length - 1];
        alts.push({ source: 'DeFiLlama /v2/historicalChainTvl/Solana（日线）', value: last.tvl, sourceUpdatedAt: last.date * 1000 });
      }
      await put1('chain_tvl', base('DeFiLlama /v2/chains', 'https://defillama.com/chain/Solana', chains, { value: c.tvl, unit: 'usd', definition: 'DeFiLlama 统计的 Solana 链上协议锁仓总价值', alts }));
    }
  }
  if (hist.error || hist.data.length < 2) await put1('tvl_30d_change', hist.error ? { ...E(hist), source: 'DeFiLlama historicalChainTvl', unit: 'pct' } : { ...nodata('历史点不足，无法计算', 'DeFiLlama'), unit: 'pct' });
  else {
    const a = hist.data[0], b = hist.data[hist.data.length - 1];
    await put1('tvl_30d_change', base('计算值：DeFiLlama historicalChainTvl', 'https://defillama.com/chain/Solana', hist, {
      value: a.tvl ? ((b.tvl - a.tvl) / a.tvl) * 100 : null, unit: 'pct', sourceUpdatedAt: b.date * 1000,
      definition: `由 ${new Date(a.date * 1000).toLocaleDateString('zh-CN')} 至 ${new Date(b.date * 1000).toLocaleDateString('zh-CN')} 的日线 TVL 计算，属于分析，不是数据源直接给出的数字`,
    }));
  }
  if (stable.error) await put1('stablecoin_supply', { ...E(stable), source: 'DeFiLlama stablecoinchains', sourceUrl: 'https://defillama.com/stablecoins/Solana', unit: 'usd' });
  else {
    const s = stable.data.find((x) => x.name === 'Solana');
    const v = s && s.totalCirculatingUSD && s.totalCirculatingUSD.peggedUSD;
    await put1('stablecoin_supply', typeof v === 'number'
      ? base('DeFiLlama stablecoinchains', 'https://defillama.com/stablecoins/Solana', stable, { value: v, unit: 'usd', definition: 'Solana 链上美元锚定稳定币流通量合计' })
      : { ...nodata('DeFiLlama 未返回 Solana 稳定币数据', 'DeFiLlama'), unit: 'usd' });
  }
  const overview = async (key, r, field, url, unit, def) => {
    if (r.error) return put1(key, { ...E(r), source: 'DeFiLlama overview', sourceUrl: url, unit });
    const v = r.data && r.data[field];
    return put1(key, typeof v === 'number' ? base('DeFiLlama overview', url, r, { value: v, unit, definition: def, sourceUpdatedAt: null }) : { ...nodata('DeFiLlama 未返回该字段', 'DeFiLlama'), unit });
  };
  await overview('dex_volume_24h', dex, 'total24h', 'https://defillama.com/dexs/chain/solana', 'usd', 'Solana 链 DEX 24 小时成交量合计（DeFiLlama 口径）');
  await overview('dex_volume_30d', dex, 'total30d', 'https://defillama.com/dexs/chain/solana', 'usd', 'Solana 链 DEX 30 天成交量合计（DeFiLlama 口径）');
  await overview('fees_24h', fees, 'total24h', 'https://defillama.com/fees/chain/solana', 'usd', 'Solana 链协议产生的费用 24 小时合计（DeFiLlama 口径）');
  await overview('revenue_24h', rev, 'total24h', 'https://defillama.com/fees/chain/solana', 'usd', 'DeFiLlama dailyRevenue 口径；统计范围以 DeFiLlama 说明为准');
  await put1('users', { ...nodata('当前未接入免费、口径明确的用户 / 活跃地址数据源；不使用估算'), unit: 'num' });

  // —— 协议层：Protocol 数据与 Token Identity / Market Data 分离 ——
  const { objs, rels } = await loadGraph();
  const protocols = objs.filter((o) => o.type === 'protocol');
  const byId = Object.fromEntries(objs.map((o) => [o.id, o]));
  // 协议匹配优先使用名称/slug 的精确或包含关系；不把“未匹配”解释成“没有活动”。
  const norm = (v) => String(v || '').trim().toLowerCase().replace(/[^a-z0-9]+/g, '');
  const match = (list, name) => {
    const n = norm(name);
    return (list || []).filter((e) => {
      const candidates = [e.displayName, e.name, e.slug, e.gecko_id].map(norm).filter(Boolean);
      return candidates.some((c) => c === n || c.startsWith(n) || n.startsWith(c));
    });
  };
  for (const p of protocols) {
    const es = !prots.error ? match(prots.data, p.name) : [];
    const entryMetric = async (key, r, list, urlOf, unit, scopeNote) => {
      if (r.error) return saveMetric(p.id, key, { ...E(r), source: 'DeFiLlama', unit });
      const entries = list.map((e) => ({ component: e.component || e.label, label: e.label, value: e.value, source: 'DeFiLlama', sourceUrl: e.url || urlOf, retrievedAt: now(r) })).filter((e) => typeof e.value === 'number');
      if (!entries.length) return saveMetric(p.id, key, { ...nodata('DeFiLlama 中未匹配到该协议的数据（按名称前缀匹配）', 'DeFiLlama'), unit });
      return saveMetric(p.id, key, base('DeFiLlama', urlOf, r, { entries, unit, definition: scopeNote }));
    };
    await entryMetric('tvl', prots, es.map((e) => ({ component: e.name, label: e.name + (e.tvl === null ? '（全链合计）' : ''), value: e.tvl ?? e.tvlAll, url: 'https://defillama.com/protocol/' + e.slug })), 'https://defillama.com/chains/Solana', 'usd', 'Protocol 组件级 TVL；多个组件不自动相加，可能存在重复或不同统计口径。');
    const ov = (r) => (r.error ? [] : match((r.data && r.data.protocols) || [], p.name));
    await entryMetric('dex_volume_24h', dex, ov(dex).map((e) => ({ component: e.displayName || e.name, label: e.displayName || e.name, value: e.total24h })), 'https://defillama.com/dexs/chain/solana', 'usd', 'Protocol 组件级 DEX Volume 24h，不自动汇总。');
    await entryMetric('fees_24h', fees, ov(fees).map((e) => ({ component: e.displayName || e.name, label: e.displayName || e.name, value: e.total24h })), 'https://defillama.com/fees/chain/solana', 'usd', 'Protocol 组件级 Fees 24h，不自动汇总。');
    await entryMetric('revenue_24h', rev, ov(rev).map((e) => ({ component: e.displayName || e.name, label: e.displayName || e.name, value: e.total24h })), 'https://defillama.com/fees/chain/solana', 'usd', 'Protocol 组件级 Revenue 24h，不自动汇总。');
    await saveMetric(p.id, 'users', { ...nodata('当前未接入口径明确的用户 / 地址数据源'), unit: 'num' });

    const t = tokenForProtocol(p.id, rels, byId);
    if (t) {
      await resolveTokenIdentity(t);
      await refreshTokenMarketData(t, say);
    }
  }

  // 生态原生 Token SOL 也独立保存为 Token Identity，市场数据不再依赖 Protocol。
  const solToken = byId['token:solana:sol'] || null;
  if (solToken) { await resolveTokenIdentity(solToken); await refreshTokenMarketData(solToken, say); }

  await setSetting('lastRefresh', Date.now());
  const errs = [chains, hist, stable, dex, fees, rev, prots].filter((r) => r.error);
  return { errors: errs.map((r) => r.error) };
}

/* ===================== 指标渲染 ===================== */
function cellValue(m) {
  if (!m) return NA;
  const st = effStatus(m);
  if (st === 'NO_DATA') return NA;
  const show = (v) => (fmtVal(v, m.unit) || NA);
  let body;
  if (m.entries) body = m.entries.map((e) => `<div>${e.url ? link(e.url, e.label) : esc(e.label)}：${show(e.value)}</div>`).join('');
  else body = show(m.value);
  if (st === 'ERROR') return `<div class="error">数据暂时无法获取</div>${m.value !== undefined || m.entries ? `<div class="muted">最后成功值：${body}（${esc(fmtTime(m.lastSuccessAt))}）</div>` : ''}<div class="muted">${esc(m.error || '')}</div>`;
  let alt = '';
  if (m.alts && m.alts.length) {
    alt = m.alts.map((a) => `<div class="muted">来源 B：${esc(a.source)} = ${show(a.value)}（${esc(fmtTime(a.sourceUpdatedAt))}）</div>`).join('') + '<div class="muted">来源 A / 来源 B：不同数据源统计范围或更新时间可能不同，请自行判断。</div>';
  }
  return body + alt;
}
function metricRows(keys, M) {
  return keys.map((k) => {
    const m = M[k];
    const st = effStatus(m);
    return `<tr><td>${esc(ML[k] || k)}</td><td>${cellValue(m)}${m && m.note ? `<div class="muted">${esc(m.note)}</div>` : ''}${m && m.definition && st !== 'NO_DATA' ? `<div class="muted">口径：${esc(m.definition)}</div>` : ''}</td><td>${tagS(st)}</td><td>${m && m.source ? link(m.sourceUrl, m.source) : '—'}</td><td>${m && m.retrievedAt ? esc(fmtTime(m.retrievedAt)) : '—'}</td><td>${m && m.sourceUpdatedAt ? esc(fmtTime(m.sourceUpdatedAt)) : '未提供'}</td></tr>`;
  }).join('');
}
const metricTable = (keys, M) => `<div class="scroll"><table><thead><tr><th>指标</th><th>值</th><th>状态</th><th>来源</th><th>获取时间</th><th>来源更新时间</th></tr></thead><tbody>${metricRows(keys, M)}</tbody></table></div>`;

/* ===================== 风险系统（只列项目，不给安全/危险结论） ===================== */
function risks(o, M, TM = M) {
  const val = (k, X = M) => (X[k] && ['AVAILABLE', 'STALE'].includes(effStatus(X[k])) && typeof X[k].value === 'number' ? X[k].value : null);
  const R = [];
  const ur = M.unlock_amount;
  R.push({ n: 'Token Unlock（代币解锁）', s: '无法确认', e: ur && ur.note ? ur.note : '尚未刷新或无解锁数据', src: 'CoinGecko（不含解锁数据）' });
  const fdv = val('fdv', TM), mc = val('market_cap', TM);
  R.push({ n: 'FDV 风险（完全稀释估值 vs 市值）', s: fdv && mc ? '已计算' : '数据不足', e: fdv && mc ? `FDV / Market Cap = ${(fdv / mc).toFixed(2)}。该比值用于描述完全稀释估值与当前流通市值之间的关系；它本身不是风险结论。未来流通稀释压力还需要结合供应量和解锁数据判断。` : '缺少 FDV 或 Market Cap', src: 'CoinGecko' });
  R.push({ n: 'Holder Concentration（持币集中度）', s: '无法确认', e: '当前未接入持币地址分布数据源', src: '—' });
  R.push({ n: 'Incentive Dependency（激励依赖）', s: '无法确认', e: '当前未接入激励 / 排放数据源', src: '—' });
  R.push({ n: 'TVL Quality（TVL 质量）', s: '数据不足', e: '当前已获得生态 TVL 总量，但尚未获得足够数据判断其构成、原生资产占比及潜在重复计算。', src: 'DeFiLlama' });
  R.push({ n: 'Native Token TVL（原生代币 TVL 影响）', s: '数据不足', e: '尚未获得按协议自身代币计价的 TVL 数据', src: '—' });
  const fe = val('fees_24h'), rv = val('revenue_24h');
  R.push({ n: 'Revenue（收入真实性）', s: fe && rv ? '已计算' : '数据不足', e: fe && rv ? `Revenue / Fees = ${((rv / fe) * 100).toFixed(1)}%（计算值；两者口径均为 DeFiLlama 24h，收入真实性仍需核对协议披露）` : (M.revenue_24h && M.revenue_24h.entries ? '协议级数据为多条目，需自行核对，不做汇总' : '缺少 Fees 或 Revenue'), src: 'DeFiLlama' });
  const keys = Object.keys(M), av = keys.filter((k) => effStatus(M[k]) === 'AVAILABLE').length;
  const bad = keys.filter((k) => ['ERROR', 'STALE'].includes(effStatus(M[k]))).length;
  R.push({ n: 'Data Quality（数据质量）', s: keys.length ? (bad ? '存在问题' : '已评估') : '数据不足', e: keys.length ? `${keys.length} 个字段：AVAILABLE ${av}，NO_DATA ${keys.filter((k) => effStatus(M[k]) === 'NO_DATA').length}，ERROR/STALE ${bad}` : '尚未刷新数据', src: '本工具' });
  R.push({ n: 'Identity（身份）', s: '已记录', e: o.contract ? `Token 合约：${o.contract}（Chain：${o.chain}）` : `Object ID：${o.id}；Chain：${o.chain || '未记录'}；${o.type === 'token' ? '该 Token 当前没有 Contract 字段，但身份记录仍可由其他来源确认。' : 'Protocol / Ecosystem 对象不要求 Contract 地址。'} 身份来源：${(o.sources || []).length} 个官方链接`, src: '官方来源' });
  return R;
}
const riskHtml = (R) => `<div class="stack">${R.map((r) => `<div class="row risk"><b>${esc(r.n)}</b><span>${esc(r.s)}</span><small>证据：${esc(r.e)}<br>来源：${esc(r.src)}</small></div>`).join('')}</div>`;

/* ===================== 研究状态 / 步骤 ===================== */
const STEPS = ['问题与范围', '对象身份', '生态地图', '整体规模', '资金与资产', '核心协议', '用户与活动', 'Fees / Revenue', 'Token', '流动性', '依赖关系', '风险', '异常', '研究分支', '证据', '结论状态', '历史快照', '报告', '自检'];
const STATUSES = ['未开始', '研究中', '数据已刷新', '部分完成', '已完成', '需要复查'];
// 研究状态按实际进度计算；用户手动选择后以手动为准（可切回“自动”）
function computeStatus(o, M, r, snaps) {
  if (r.override && STATUSES.includes(r.override)) return { status: r.override, reason: '手动设置' };
  const sts = Object.values(M).map(effStatus);
  const refreshed = sts.includes('AVAILABLE') || sts.includes('STALE');
  const bad = sts.filter((x) => x === 'ERROR' || x === 'STALE').length;
  const steps = (r.steps || []).length;
  if (refreshed && bad) return { status: '需要复查', reason: `${bad} 个字段为 ERROR 或 STALE` };
  if (o.type === 'ecosystem' && steps >= STEPS.length) return { status: '已完成', reason: `${STEPS.length} 步全部勾选` };
  if (refreshed && (snaps.length || steps)) return { status: '部分完成', reason: `已刷新数据${snaps.length ? '、已保存 ' + snaps.length + ' 条快照' : ''}${steps ? '、已勾选 ' + steps + ' 步' : ''}` };
  if (refreshed) return { status: '数据已刷新', reason: '已刷新数据，尚未保存快照' };
  if (steps || snaps.length) return { status: '研究中', reason: '已有研究记录，尚未刷新数据' };
  return { status: '未开始', reason: '尚无数据、快照或进度' };
}
async function statusFor(o) {
  const [M, r, snaps] = [await metricsFor(o.id), await getResearch(o.id), await snapsFor(o.id)];
  return computeStatus(o, M, r, snaps);
}
const getResearch = async (id) => (await get('research', 'status:' + id).catch(() => null)) || { id: 'status:' + id, objectId: id, status: '未开始', steps: [], updatedAt: null };

/* ===================== 快照 / 历史（只追加，不覆盖） ===================== */
// 历史快照的 Volume 统一定义为“关联 Token 的 24h 代币成交量”。
// Protocol 的 DEX Volume 仍单独保存在 metrics.dex_volume_24h，不冒充 Token Volume。
const SNAP_KEYS = [['price', 'price'], ['market_cap', 'market_cap'], ['fdv', 'fdv'], ['tvl', null], ['volume', 'volume_24h'], ['fees', 'fees_24h'], ['revenue', 'revenue_24h'], ['users', 'users']];
async function associatedTokenMetrics(o) {
  const { rels, byId } = await loadGraph();
  const t = tokenForProtocol(o.id, rels, byId) || (o.type === 'ecosystem' ? tokenForProtocol(o.id, rels, byId) : null);
  return t ? await metricsFor(t.id) : {};
}
function snapValue(o, col, M, TM = {}) {
  const key = col === 'tvl' ? (o.type === 'ecosystem' ? 'chain_tvl' : 'tvl') : SNAP_KEYS.find((x) => x[0] === col)[1];
  const tokenMetricCols = ['price', 'market_cap', 'fdv', 'volume'];
  const m = (['protocol','ecosystem'].includes(o.type) && tokenMetricCols.includes(col) ? TM[key] : null) || M[key];
  const st = effStatus(m);
  if (!m || !['AVAILABLE', 'STALE'].includes(st)) return null;
  const src = m.source || '';
  if (m.entries) return { entries: m.entries.map((e) => ({ label: e.label, value: e.value })), unit: m.unit, source: src };
  return typeof m.value === 'number' ? { value: m.value, unit: m.unit, source: src } : null;
}
async function saveSnapshot(o, notes) {
  const M = await metricsFor(o.id);
  const TM = ['protocol', 'ecosystem'].includes(o.type) ? await associatedTokenMetrics(o) : {};
  const now = new Date();
  const values = {};
  for (const [col] of SNAP_KEYS) values[col] = snapValue(o, col, M, TM);
  const rec = { id: `snap:${o.id}:${now.getTime()}`, objectId: o.id, date: now.toLocaleDateString('sv-SE'), createdAt: now.getTime(), values, notes: notes || '' };
  await put('snapshots', rec);
  return rec;
}
const snapsFor = async (id) => (await getAll('snapshots').catch(() => [])).filter((s) => s.objectId === id).sort((a, b) => b.createdAt - a.createdAt);
function snapCell(v) {
  if (!v) return NA;
  if (v.entries) return v.entries.map((e) => `<div>${esc(e.label)}：${esc(fmtVal(e.value, v.unit))}</div>`).join('');
  return esc(fmtVal(v.value, v.unit));
}

/* ===================== 报告（Markdown：事实 / 分析分开） ===================== */
const mdv = (m) => {
  if (!m) return '暂无数据';
  const st = effStatus(m);
  if (st === 'NO_DATA') return '暂无数据';
  if (st === 'ERROR') return '数据暂时无法获取（最后成功获取：' + fmtTime(m.lastSuccessAt) + '）';
  if (m.entries) return m.entries.map((e) => `${e.label}: ${fmtVal(e.value, m.unit)}`).join('；');
  return fmtVal(m.value, m.unit) || '暂无数据';
};
const mdFact = (k, M) => {
  const m = M[k];
  const st = effStatus(m);
  return `- 事实：${(ML[k] || k).split('（')[0]} = ${mdv(m)} ｜ 状态：${st}${m && m.source ? ` ｜ 来源：${m.source}${m.sourceUrl ? ' ' + m.sourceUrl : ''}` : ''}${m && m.retrievedAt ? ` ｜ 获取：${fmtTime(m.retrievedAt)}` : ''}${m && m.note ? ` ｜ 说明：${m.note}` : ''}`;
};
async function buildReport(id) {
  const { byId, rels } = await loadGraph();
  const o = byId[id];
  if (!o) return '# 未找到对象\n';
  const M = await metricsFor(id);
  const st = await statusFor(o);
  const snaps = (await snapsFor(id)).slice().reverse();
  const L = [];
  L.push(`# ${o.name}${o.symbol ? '（' + o.symbol + '）' : ''} 研究报告`);
  L.push(`> 生成时间：${fmtTime(Date.now())} ｜ 研究状态：${st.status}（${st.reason}）`);
  L.push('> 本报告仅用于研究与记录，不是投资建议。未知 = 暂无数据；估算不被使用。', '');
  L.push('## Identity', `- 名称：${o.name}`, `- Symbol：${o.symbol || '无'}`, `- 类型：${cap(o.type)}`, `- Object ID：${o.id}`, `- Chain：${o.chain || '未记录'}`);
  if (o.contract) L.push(`- Contract：${o.contract}`);
  L.push(`- 身份说明：${o.identity || '暂无'}`, `- 官方网站：${o.website || '暂无'}`, `- 身份来源：${(o.sources || []).map((s) => `${s.label} ${s.url}`).join('；') || '暂无'}`, '');
  L.push('## Ecosystem');
  const out = rels.filter((x) => x.from === o.id && byId[x.to]);
  if (o.type === 'ecosystem') {
    const ps = rels.filter((x) => x.type === 'part_of_ecosystem' && x.to === o.id && byId[x.from]);
    L.push(`- 已确认的生态内项目（${ps.length}）：${ps.map((x) => byId[x.from].name).join('、') || '无'}`);
  } else if (out.length) out.forEach((x) => L.push(`- ${x.type === 'part_of_ecosystem' ? '所属生态' : x.type === 'in_category' ? '类别' : x.type === 'associated_token' ? '关联 Token' : x.type}：${byId[x.to].name}${byId[x.to].symbol ? '（' + byId[x.to].symbol + '）' : ''}（${x.status}）｜ 依据：${x.note || '无'}`));
  else L.push('- 暂无关系记录');
  L.push('', '## Product', `- 事实（身份说明）：${o.identity || '暂无数据'}`, '');
  L.push('## Users', mdFact('users', M), '');
  L.push('## Capital');
  (o.type === 'ecosystem' ? ['chain_tvl', 'stablecoin_supply', 'dex_volume_24h', 'dex_volume_30d'] : ['tvl', 'dex_volume_24h']).forEach((k) => L.push(mdFact(k, M)));
  const ch = M.tvl_30d_change;
  if (ch && effStatus(ch) !== 'NO_DATA' && typeof ch.value === 'number') L.push(`- 分析（计算值，非数据源直接给出）：TVL 近 30 天变化 ${fmtVal(ch.value, 'pct')}（${ch.definition || ''}）`);
  L.push('', '## Revenue', mdFact('fees_24h', M), mdFact('revenue_24h', M), '');
  const reportToken = ['protocol','ecosystem'].includes(o.type) ? tokenForProtocol(o.id, rels, byId) : (o.type === 'token' ? o : null);
  const TM = reportToken ? await metricsFor(reportToken.id) : M;
  if (reportToken) {
    L.push(
      '## Token Identity',
      `- Token：${reportToken.name}（${reportToken.symbol}）`,
      `- Object ID：${reportToken.id}`,
      `- Chain：${reportToken.chain || '未记录'}`,
      `- Identity Status：${reportToken.identityStatus || 'NOT_FOUND'}`,
      `- Identity Source：${reportToken.identitySource || '暂无'}`,
      `- Contract：${reportToken.contractAddress || '不适用 / 未记录'}`,
      `- CoinGecko ID：${reportToken.gecko_id || '暂无'}`,
      ''
    );
  }
  L.push('## Token', ...['price', 'market_cap', 'volume_24h', 'ath', 'atl'].map((k) => mdFact(k, TM)), '');
  L.push('## Tokenomics', ...['total_supply', 'circulating_supply', 'fdv', 'unlock_amount', 'unlocked_amount', 'next_unlock'].map((k) => mdFact(k, TM)));
  const f = TM.fdv, mcm = TM.market_cap;
  if (f && mcm && typeof f.value === 'number' && typeof mcm.value === 'number' && mcm.value) L.push(`- 分析（计算值）：FDV / Market Cap = ${(f.value / mcm.value).toFixed(2)}`);
  L.push('', '## Risks');
  risks(o, M, TM).forEach((x) => L.push(`- ${x.n}：${x.s} ｜ 证据：${x.e} ｜ 来源：${x.src}`));
  L.push('', '## Data Gaps');
  const protocolGapKeys = o.type === 'ecosystem' ? ['chain_tvl', 'stablecoin_supply', 'dex_volume_24h', 'dex_volume_30d', 'users'] : ['tvl', 'dex_volume_24h', 'fees_24h', 'revenue_24h', 'users'];
  const tokenGapKeys = reportToken ? ['price', 'market_cap', 'fdv', 'volume_24h', 'ath', 'atl', 'total_supply', 'circulating_supply', 'unlock_amount', 'unlocked_amount', 'next_unlock'] : [];
  const gapRows = [];
  for (const k of protocolGapKeys) if (effStatus(M[k]) !== 'AVAILABLE') gapRows.push([k, M[k]]);
  for (const k of tokenGapKeys) if (effStatus(TM[k]) !== 'AVAILABLE') gapRows.push([k, TM[k]]);
  if (gapRows.length) gapRows.forEach(([k, m]) => L.push(`- ${(ML[k] || k).split('（')[0]}：${effStatus(m)}${m && (m.note || m.error) ? '（' + (m.note || m.error) + '）' : '（尚未刷新数据）'}`)); else L.push('- 无');
  L.push('', '## Historical Data');
  if (!snaps.length) L.push('暂无历史快照。');
  else {
    L.push('| Date | Price | MC | FDV | TVL | Volume | Fees | Revenue | Users | Notes |', '|---|---|---|---|---|---|---|---|---|---|');
    const cellMd = (v) => (!v ? '暂无数据' : v.entries ? v.entries.map((e) => `${e.label}: ${fmtVal(e.value, v.unit)}`).join('; ') : fmtVal(v.value, v.unit));
    snaps.forEach((s) => L.push(`| ${s.date} | ${['price', 'market_cap', 'fdv', 'tvl', 'volume', 'fees', 'revenue', 'users'].map((c) => cellMd(s.values[c])).join(' | ')} | ${(s.notes || '').replace(/\|/g, '/').replace(/\n/g, ' ')} |`));
    if (snaps.length >= 2) {
      const a = snaps[snaps.length - 2].values.price, b = snaps[snaps.length - 1].values.price;
      if (a && b && typeof a.value === 'number' && typeof b.value === 'number' && a.value) L.push('', `分析（计算值）：最近两次快照之间价格变化 ${fmtVal(((b.value - a.value) / a.value) * 100, 'pct')}。`);
    }
  }
  return L.join('\n') + '\n';
}

/* ===================== 路由 / 页面 ===================== */
let renderToken = 0;
const ROUTES = { home: pageHome, search: pageSearch, research: pageResearch, history: pageHistory, report: pageReport, selfcheck: pageSelfCheck };
const NAV = [['home', '首页'], ['search', '搜索'], ['research', '研究'], ['history', '历史'], ['report', '报告'], ['selfcheck', '自检']];
const parseHash = () => {
  const [r, ...rest] = (location.hash.slice(1) || 'home').split('/');
  let p = null;
  try { p = rest.length ? decodeURIComponent(rest.join('/')) : null; } catch { /* ignore */ }
  return { route: ROUTES[r] ? r : 'home', param: p };
};
async function render() {
  const my = ++renderToken;
  const { route, param } = parseHash();
  const app = document.querySelector('#app');
  app.innerHTML = `<header><div class="brand">加密货币生态研究工具</div><nav>${NAV.map(([k, l]) => `<a class="navlink ${route === k ? 'active' : ''}" href="#${k}">${l}</a>`).join('')}</nav></header><main id="main"><div class="loading">加载中…</div></main>`;
  let html;
  try { html = await ROUTES[route](param); } catch (e) { errLog.push(route + ': ' + (e && e.message)); html = `<div class="panel"><h2>页面加载失败</h2><p class="error">${esc(e && e.message)}</p><p class="muted">其他页面仍可使用。</p></div>`; }
  if (my !== renderToken) return;
  document.querySelector('#main').innerHTML = html;
  if (route === 'search') bindSearch();
}

async function pageHome() {
  const { objs, byId } = await loadGraph();
  const cur = byId[await getSetting('current')] || byId[ECO_ID];
  const all = await getAll('metrics').catch(() => []);
  const cnt = { AVAILABLE: 0, NO_DATA: 0, ERROR: 0, STALE: 0 };
  all.forEach((m) => { cnt[effStatus(m)] = (cnt[effStatus(m)] || 0) + 1; });
  const last = await getSetting('lastRefresh');
  const rs = (await getAll('research').catch(() => [])).filter((r) => r.updatedAt).sort((a, b) => b.updatedAt - a.updatedAt).slice(0, 5);
  const snaps = (await getAll('snapshots').catch(() => [])).sort((a, b) => b.createdAt - a.createdAt).slice(0, 5);
  const r = cur ? await getResearch(cur.id) : null;
  const curSt = cur ? await statusFor(cur) : null;
  const protos = objs.filter((o) => o.type === 'protocol');
  const tokens = objs.filter((o) => o.type === 'token');
  const doneN = r ? r.steps.length : 0;
  return `<section class="hero"><span class="eyebrow">V1 · Local First</span><h1>从生态地图开始研究</h1><p>生态 → 项目 → 数据 → Token → 风险 → 历史 → 报告，放在同一个工作空间。数据来自公开免费接口，缺失就显示“暂无数据”。</p></section>
  <section class="panel"><h2>当前研究对象</h2>${cur ? `<div class="row"><b>${esc(cur.name)}${cur.symbol ? ' · ' + esc(cur.symbol) : ''}</b><span>${esc(cap(cur.type))}</span><small>${esc(cur.identity || '')}</small></div>
  <dl class="kv"><dt>Ecosystem 生态</dt><dd>${esc(byId[cur.parent_id || ECO_ID]?.name || cur.name)}</dd><dt>Chain 链</dt><dd>${esc(cur.chain || '未记录')}</dd><dt>Protocol 协议</dt><dd>${protos.map((p) => `<a href="#research/${encodeURIComponent(p.id)}">${esc(p.name)}</a>`).join('、') || '暂无'}</dd><dt>Token 代币</dt><dd>${esc(cur.symbol || '暂无')}${tokens.length ? '；已保存 Token 对象：' + tokens.map((t) => `<a href="#research/${encodeURIComponent(t.id)}">${esc(t.name)}</a>`).join('、') : ''}</dd><dt>研究状态</dt><dd>${esc(curSt.status)}（${esc(curSt.reason)}）</dd><dt>研究进度</dt><dd>${cur.type === 'ecosystem' ? `${doneN} / ${STEPS.length} 步` : '见研究页状态'}</dd></dl>
  <p><a class="btn" href="#research/${encodeURIComponent(cur.id)}">进入研究</a></p>` : '<div class="empty">暂无对象</div>'}</section>
  <section class="panel"><h2>数据状态</h2><p>AVAILABLE ${cnt.AVAILABLE} · NO_DATA ${cnt.NO_DATA} · ERROR ${cnt.ERROR} · STALE ${cnt.STALE}</p><p class="muted">最近一次刷新：${esc(fmtTime(last))}${all.length ? '' : '（尚未刷新数据，进入研究页点击“刷新数据”）'}</p></section>
  <section class="panel"><h2>最近研究</h2>${rs.length || snaps.length ? [...rs.map((x) => `<div>${esc(byId[x.objectId]?.name || x.objectId)} · ${esc(fmtTime(x.updatedAt))}</div>`), ...snaps.map((s) => `<div>快照 · ${esc(byId[s.objectId]?.name || s.objectId)} · ${esc(s.date)}</div>`)].join('') : '<div class="muted">暂无研究记录。</div>'}</section>
  <section class="panel"><h2>建议路径</h2><ol><li>搜索 Solana / Jupiter</li><li>确认对象身份与关系</li><li>刷新数据，查看指标与来源</li><li>设置研究状态，保存快照</li><li>生成并复制报告</li></ol></section>`;
}

/* —— 搜索 —— */
const SEARCH_FIELDS = ['id', 'name', 'symbol', 'type', 'chain', 'ecosystem', 'identity', 'contract', 'mint', 'program'];
let searchObjs = [];
async function pageSearch() {
  searchObjs = (await loadGraph()).objs;
  return `<section><h1>Universal Search / 全局搜索</h1><p>按名称、Symbol、Object ID、Contract、Mint、Program 搜索。同名 Token 会同时显示 Chain 与 Contract，Contract + Chain 优先于名称。</p><input id="q" placeholder="例如 Jupiter / SOL / 合约地址"/><div id="results" class="stack"></div><div id="lookup"></div></section>`;
}
function bindSearch() {
  const q = document.querySelector('#q'), out = document.querySelector('#results');
  const hay = (o) => SEARCH_FIELDS.map((k) => o[k]).filter((v) => v != null).join(' ').toLowerCase();
  const score = (o, e) => { const n = String(o.name || '').toLowerCase(), s = String(o.symbol || '').toLowerCase(), c = String(o.contract || '').toLowerCase(), i = String(o.id || '').toLowerCase(); return c === e ? 4 : (n === e || s === e || i === e) ? 3 : (n.startsWith(e) || s.startsWith(e)) ? 2 : 1; };
  const run = () => {
    const e = q.value.trim().toLowerCase();
    const lk = document.querySelector('#lookup'); lk.innerHTML = '';
    if (!e) { out.innerHTML = '<div class="empty">请输入搜索内容</div>'; return; }
    const res = searchObjs.filter((o) => hay(o).includes(e)).sort((a, b) => score(b, e) - score(a, e));
    out.innerHTML = res.length ? res.map((o) => `<a class="row" href="#research/${encodeURIComponent(o.id)}"><b>${esc(o.name || o.id)}${o.symbol ? ' · ' + esc(o.symbol) : ''}</b><span>${esc(o.type || '')}</span><small>Chain：${esc(o.chain || '未记录')}${o.contract ? ' · Contract：' + esc(o.contract) : ''}<br>${esc(o.identity || '')}</small></a>`).join('') : '<div class="empty">本地暂无匹配对象</div>';
    if (/^(0x[a-fA-F0-9]{40}|[1-9A-HJ-NP-Za-km-z]{32,44})$/.test(e.trim()) || e.length >= 32) {
      lk.innerHTML = `<div class="panel"><h3>在线查询合约（CoinGecko）</h3><p class="muted">选择该合约所在链后查询；结果不会自动保存。</p><select id="plat"><option value="solana">Solana</option><option value="ethereum">Ethereum</option><option value="base">Base</option><option value="arbitrum-one">Arbitrum One</option><option value="binance-smart-chain">BNB Chain</option></select> <button class="btn" data-act="lookup">查询</button><div id="lookres"></div></div>`;
    }
  };
  q.oninput = run; run();
}
async function doLookup() {
  const addr = document.querySelector('#q').value.trim(), plat = document.querySelector('#plat').value, box = document.querySelector('#lookres');
  box.innerHTML = '<div class="loading">查询中…</div>';
  const r = await fetchJSON(`${CG}/coins/${plat}/contract/${encodeURIComponent(addr)}`, { ttl: 5 * 60 * 1000 });
  if (r.error) { box.innerHTML = `<p class="error">数据暂时无法获取：${esc(r.error)}</p><p class="muted">来源：CoinGecko；未保存任何内容。</p>`; return; }
  const d = r.data;
  globalThis.__lookup = { id: `token:${plat}:${addr.toLowerCase()}`, name: d.name, symbol: String(d.symbol || '').toUpperCase(), type: 'token', chain: plat, contract: addr, contractAddress: addr, token_type: '链上代币（CoinGecko 资料）', identityStatus: 'CONFIRMED', identitySource: 'Contract + Chain → CoinGecko', website: (d.links && d.links.homepage && d.links.homepage[0]) || '', explorer: (d.links && d.links.blockchain_site && d.links.blockchain_site.find(Boolean)) || '', gecko_id: d.id, identity: `${d.name}（${String(d.symbol || '').toUpperCase()}）· ${plat} 链上代币 · CoinGecko ID ${d.id}`, sources: [{ label: 'CoinGecko', url: 'https://www.coingecko.com/en/coins/' + d.id }], data_status: 'identity_only' };
  const t = globalThis.__lookup;
  box.innerHTML = `<dl class="kv"><dt>Name</dt><dd>${esc(t.name)}</dd><dt>Symbol</dt><dd>${esc(t.symbol)}</dd><dt>Chain</dt><dd>${esc(t.chain)}</dd><dt>Contract</dt><dd>${esc(t.contract)}</dd><dt>Identity Source</dt><dd>${link(t.sources[0].url, 'CoinGecko')}</dd></dl><button class="btn" data-act="savetoken">保存为研究对象</button>`;
}

/* —— 研究页 —— */
async function pageResearch(param) {
  const { objs, rels, byId } = await loadGraph();
  const id = param || (await getSetting('current')) || ECO_ID;
  const o = byId[id];
  if (!o) return `<section><h1>Research Workspace / 研究工作台</h1><div class="empty">未找到对象：${esc(id)}。<a href="#search">去搜索</a></div></section>`;
  await setSetting('current', id);
  const M = await metricsFor(id);
  const r = await getResearch(id);
  const stNow = computeStatus(o, M, r, await snapsFor(id));
  const r0 = (l, v) => (v ? `<dt>${l}</dt><dd>${v}</dd>` : '');
  const parent = o.parent_id && byId[o.parent_id];
  const relRows = rels.filter((l) => l.from === o.id && byId[l.to]).map((l) => r0(l.type === 'part_of_ecosystem' ? '所属生态' : l.type === 'in_category' ? '类别' : l.type === 'associated_token' ? '关联 Token' : esc(l.type), `<a href="#research/${encodeURIComponent(l.to)}">${esc(byId[l.to].name)}</a> ${confTag(l.status)}${l.note ? `<small class="muted">${esc(l.note)}</small>` : ''}${l.sources && l.sources.length ? `<small>来源：${srcLinks(l.sources)}</small>` : ''}`)).join('');
  const identity = `<div class="panel"><h2>${esc(o.name || o.id)} <span class="muted">${esc(o.symbol || '')}</span></h2><dl class="kv">${r0('名称', esc(o.name))}${r0('Symbol', esc(o.symbol))}${r0('类型', esc(cap(o.type)))}${r0('Object ID', esc(o.id))}${r0('Chain', esc(o.chain))}${r0('Contract', esc(o.contractAddress || o.contract))}${r0('Token Type', esc(o.token_type))}${r0('身份说明', esc(o.identity))}${parent ? r0('所属生态', `<a href="#research/${encodeURIComponent(parent.id)}">${esc(parent.name)}</a>`) : ''}${relRows}${r0('官方网站', o.website ? link(o.website) : '')}${r0('Explorer', o.explorer ? link(o.explorer) : '')}${r0('身份来源', srcLinks(o.sources))}</dl></div>`;
  const controls = `<div class="panel"><h2>研究控制</h2><p><button class="btn" data-act="refresh" data-id="${esc(id)}">刷新数据</button> <button class="btn" data-act="snapshot" data-id="${esc(id)}">保存快照</button> <a class="btn" href="#report/${encodeURIComponent(id)}">查看报告</a></p><div id="msg" class="muted"></div>
  <p>当前研究状态：<b>${esc(stNow.status)}</b> <span class="muted">（${esc(stNow.reason)}）</span></p><label>手动覆盖 <select data-act="status" data-id="${esc(id)}"><option value="">自动（按进度计算）</option>${STATUSES.map((s) => `<option ${s === r.override ? 'selected' : ''}>${s}</option>`).join('')}</select></label>
  <textarea id="snapnote" placeholder="快照备注（可选）"></textarea>
  ${o.type === 'ecosystem' ? `<h3>研究进度：${r.steps.length} / ${STEPS.length}</h3><div class="steps">${STEPS.map((s, i) => `<label><input type="checkbox" data-act="step" data-id="${esc(id)}" data-i="${i}" ${r.steps.includes(i) ? 'checked' : ''}/> ${i + 1}. ${esc(s)}</label>`).join('')}</div>` : ''}</div>`;

  let body = '';
  if (o.type === 'ecosystem') {
    const cats = objs.filter((x) => x.type === 'category' && x.parent_id === id).sort((a, b) => (a.sort_order || 0) - (b.sort_order || 0));
    const protos = objs.filter((x) => x.type === 'protocol' && x.ecosystem === o.ecosystem);
    const confirmed = (cid) => rels.filter((l) => l.type === 'in_category' && l.to === cid && l.status === 'confirmed' && byId[l.from]);
    const map = `<ul class="eco-map">${cats.map((c) => `<li><h3>${esc(c.name)}</h3>${confirmed(c.id).length ? `<ul>${confirmed(c.id).map((l) => `<li><a href="#research/${encodeURIComponent(l.from)}">${esc(byId[l.from].name)}${byId[l.from].symbol ? ' · ' + esc(byId[l.from].symbol) : ''}</a> ${confTag(l.status)}<small class="muted">依据：${esc(l.note || '')}</small><small>来源：${srcLinks(l.sources)}</small></li>`).join('')}</ul>` : '<p class="muted">暂无已确认对象</p>'}</li>`).join('')}</ul>`;
    const pm = await Promise.all(protos.map(async (p) => [p, await metricsFor(p.id)]));
    const ptab = `<div class="scroll"><table><thead><tr><th>项目</th><th>TVL</th><th>DEX Volume 24h</th><th>Fees 24h</th><th>Revenue 24h</th><th>状态</th></tr></thead><tbody>${pm.map(([p, m]) => `<tr><td><a href="#research/${encodeURIComponent(p.id)}">${esc(p.name)}</a></td>${['tvl', 'dex_volume_24h', 'fees_24h', 'revenue_24h'].map((k) => `<td>${cellValue(m[k])}</td>`).join('')}<td>${['tvl', 'dex_volume_24h', 'fees_24h', 'revenue_24h'].map((k) => tagS(effStatus(m[k]))).join(' ')}</td></tr>`).join('')}</tbody></table></div><p class="muted">协议数据按名称前缀匹配 DeFiLlama 条目，子产品条目分别列出，不做汇总。</p>`;
    const tokenRows = await Promise.all(protos.map(async (p) => { const t = tokenForProtocol(p.id, rels, byId); return [p, t, t ? await metricsFor(t.id) : {}]; }));
    const ttab = `<div class="scroll"><table><thead><tr><th>项目 / Token</th><th>Price</th><th>Market Cap</th><th>FDV</th><th>Circulating Supply</th><th>Identity</th><th>状态</th></tr></thead><tbody>${tokenRows.map(([p, t, tm]) => `<tr><td>${t ? `<a href="#research/${encodeURIComponent(t.id)}">${esc(t.name)} · ${esc(t.symbol || '')}</a>` : `${esc(p.name)} · ${esc(p.symbol || '')}`}</td>${['price', 'market_cap', 'fdv', 'circulating_supply'].map((k) => `<td>${cellValue(tm[k])}</td>`).join('')}<td>${t ? esc(t.identityStatus || 'NOT_FOUND') : 'NOT_FOUND'}</td><td>${tagS(effStatus(tm.price))}</td></tr>`).join('')}</tbody></table></div>`;
    body = `<div class="panel"><h2>第一层 · 生态：${esc(o.name)} 整体规模</h2>${metricTable(ECO_KEYS, M)}</div>
    <div class="panel"><h2>第二层 · 项目（生态地图）</h2>${map}</div>
    <div class="panel"><h2>第三层 · 项目数据</h2>${ptab}</div>
    <div class="panel"><h2>第四层 · Token</h2><h3>${esc(o.symbol)}（生态原生代币）</h3>${metricTable(TOKEN_KEYS, M)}<h3>各项目 Token 概览</h3>${ttab}</div>
    <div class="panel"><h2>第五层 · 风险</h2><p class="muted">只列出风险项目与证据，不给“安全 / 危险”结论。</p>${riskHtml(risks(o, M))}</div>`;
  } else if (o.type === 'protocol' || o.type === 'token') {
    if (o.type === 'protocol') {
      const t = tokenForProtocol(o.id, rels, byId);
      const TM = t ? await metricsFor(t.id) : {};
      const ti = t ? `<p class="muted">Token Identity：${esc(t.name)} · ${esc(t.symbol)} · ${esc(t.chain)}${t.contractAddress ? ' · Contract ' + esc(t.contractAddress) : ''} · ${esc(t.identityStatus || 'NOT_FOUND')}</p>` : '<p class="muted">未建立关联 Token。</p>';
      body = `<div class="panel"><h2>项目数据</h2>${metricTable(PROTO_KEYS, M)}</div><div class="panel"><h2>关联 Token</h2>${ti}${t ? metricTable(TOKEN_KEYS, TM) : NA}</div><div class="panel"><h2>风险</h2>${riskHtml(risks(o, M))}</div>`;
    } else {
      body = `<div class="panel"><h2>Token Market Data</h2><p class="muted">Identity Status：${esc(o.identityStatus || 'NOT_FOUND')} · Identity Source：${esc(o.identitySource || '暂无')}</p>${metricTable(TOKEN_KEYS, M)}</div><div class="panel"><h2>风险</h2>${riskHtml(risks(o, M))}</div>`;
    }
  } else body = `<div class="panel"><p class="muted">分类对象，仅用于生态地图。</p></div>`;
  return `<section><h1>Research Workspace / 研究工作台</h1>${identity}${controls}${body}</section>`;
}
const confTag = (s) => { const k = ['confirmed', 'unconfirmed'].includes(s) ? s : 'unknown'; return `<span class="tag ${k}">${cap(k)}</span>`; };
const srcLinks = (a) => { const seen = new Set(); return (Array.isArray(a) ? a : []).filter((x) => x && !seen.has(x.url) && seen.add(x.url)).map((x) => link(x.url, x.label)).join(' · '); };

async function refreshObject(id) {
  const msg = document.querySelector('#msg');
  const say = (t) => { if (msg) msg.textContent = t; };
  const { byId } = await loadGraph();
  const o = byId[id];
  say('刷新中，请稍候…');
  if (o && (o.type === 'ecosystem' || o.type === 'protocol')) {
    const res = await refreshAll(say);
    say(res.errors.length ? `部分数据源失败：${res.errors.join('；')}。失败的字段已标记 ERROR，其余已更新。` : '刷新完成。');
  } else if (o && o.type === 'token') {
    await refreshTokenMarketData(o, say);
    await setSetting('lastRefresh', Date.now());
    say(o.identityStatus === 'AMBIGUOUS' ? 'Token Identity 存在多个候选，需要确认。' : o.identityStatus === 'NOT_FOUND' ? 'Token Identity 尚未确认，未填充市场数据。' : '刷新完成。');
  } else if (o && geckoIdFor(o)) {
    const gid = geckoIdFor(o);
    const mk = await fetchJSON(`${CG}/coins/markets?vs_currency=usd&ids=${encodeURIComponent(gid)}&per_page=1&sparkline=false`, { ttl: 5 * 60 * 1000 });
    const m = mk.error ? null : (mk.data || [])[0];
    for (const [k, f, u] of [['price', 'current_price', 'usd'], ['market_cap', 'market_cap', 'usd'], ['fdv', 'fully_diluted_valuation', 'usd'], ['volume_24h', 'total_volume', 'usd'], ['total_supply', 'total_supply', 'num'], ['circulating_supply', 'circulating_supply', 'num'], ['ath', 'ath', 'usd'], ['atl', 'atl', 'usd']]) {
      if (mk.error) await saveMetric(id, k, { status: 'ERROR', error: mk.error, source: 'CoinGecko', unit: u, retrievedAt: Date.now() });
      else if (!m || typeof m[f] !== 'number') await saveMetric(id, k, { status: 'NO_DATA', note: 'CoinGecko 未提供该字段', source: 'CoinGecko', unit: u, retrievedAt: Date.now() });
      else await saveMetric(id, k, { status: 'AVAILABLE', value: m[f], unit: u, source: 'CoinGecko /coins/markets', sourceUrl: 'https://www.coingecko.com/en/coins/' + gid, retrievedAt: mk.t, sourceUpdatedAt: m.last_updated ? Date.parse(m.last_updated) : null });
    }
    await setSetting('lastRefresh', Date.now()); say(mk.error ? '数据暂时无法获取：' + mk.error : '刷新完成。');
  } else say('该对象没有可刷新的数据源。');
  render();
}

/* —— 历史页 —— */
async function pageHistory(param) {
  const { objs, byId } = await loadGraph();
  const id = param || (await getSetting('current')) || ECO_ID;
  const opts = objs.filter((o) => ['ecosystem', 'protocol', 'token'].includes(o.type));
  const snaps = await snapsFor(id);
  const cols = ['price', 'market_cap', 'fdv', 'tvl', 'volume', 'fees', 'revenue', 'users'];
  return `<section><h1>History / 历史</h1><label>对象 <select data-act="histobj">${opts.map((o) => `<option value="${esc(o.id)}" ${o.id === id ? 'selected' : ''}>${esc(o.name)}</option>`).join('')}</select></label>
  <p class="muted">每次“保存快照”都会新增一条记录，不会覆盖过去的数据。缺失字段显示“暂无数据”，不会填 0。</p>
  ${snaps.length ? `<div class="scroll"><table><thead><tr><th>Date</th><th>Price</th><th>MC</th><th>FDV</th><th>TVL</th><th>Volume</th><th>Fees</th><th>Revenue</th><th>Users</th><th>Notes</th></tr></thead><tbody>${snaps.map((s) => `<tr><td>${esc(s.date)}<div class="muted">${esc(fmtTime(s.createdAt))}</div></td>${cols.map((c) => `<td>${snapCell(s.values[c])}</td>`).join('')}<td>${esc(s.notes || '')}</td></tr>`).join('')}</tbody></table></div>` : `<div class="empty">${esc(byId[id]?.name || id)} 暂无历史快照。去研究页刷新数据后点击“保存快照”。</div>`}</section>`;
}

/* —— 报告页 —— */
async function pageReport(param) {
  const { objs } = await loadGraph();
  const id = param || (await getSetting('current')) || ECO_ID;
  const md = await buildReport(id);
  globalThis.__report = md; globalThis.__reportId = id;
  const opts = objs.filter((o) => ['ecosystem', 'protocol', 'token'].includes(o.type));
  return `<section><h1>Report / 报告</h1><label>对象 <select data-act="reportobj">${opts.map((o) => `<option value="${esc(o.id)}" ${o.id === id ? 'selected' : ''}>${esc(o.name)}</option>`).join('')}</select></label>
  <p><button class="btn" data-act="copy">Copy Report（复制 Markdown）</button> <button class="btn" data-act="download">下载 .md</button> <span id="msg" class="muted"></span></p>
  <pre class="report">${esc(md)}</pre></section>`;
}

/* —— 自检 —— */
const API_TESTS = [
  ['DeFiLlama chains', LL + '/v2/chains'],
  ['DeFiLlama stablecoins', SL + '/stablecoinchains'],
  // 使用实际业务接口测试 CoinGecko，而不是只测试 /ping。
  ['CoinGecko markets', CG + '/coins/markets?vs_currency=usd&ids=bitcoin&sparkline=false']
];
async function runChecks(withApi) {
  const C = [];
  const add = (group, name, level, detail) => C.push({ group, name, level, detail: detail || '' });
  // Project
  add('Project', '页面容器已挂载', document.querySelector('#app') && document.querySelector('header nav') ? 'PASS' : 'FAIL', '');
  for (const [k] of NAV) add('Project', `路由 #${k} 已注册`, typeof ROUTES[k] === 'function' ? 'PASS' : 'FAIL');
  add('Project', '运行期 JavaScript 错误', errLog.length ? 'WARNING' : 'PASS', errLog.slice(-3).join(' | '));
  // Data / V2 backend
  let objs = [], rels = [], metrics = [];
  try {
    const ok = await initCloud();
    add('Data', 'V2 Backend / D1', ok ? 'PASS' : 'WARNING', ok ? 'Cloudflare API + D1 已连接' : '后端未连接：自动使用 IndexedDB 本地回退');
  } catch (e) {
    add('Data', 'V2 Backend / D1', 'WARNING', '后端检测失败：' + String(e.message || e) + '；继续使用本地回退');
  }
  try { await db(); add('Data', 'IndexedDB 可用', 'PASS'); } catch (e) { add('Data', 'IndexedDB 可用', 'FAIL', String(e)); }
  const d = await db().catch(() => null);
  if (d) { const miss = STORES.filter((s) => !d.objectStoreNames.contains(s)); add('Data', `全部 ${STORES.length} 个 Store 存在`, miss.length ? 'FAIL' : 'PASS', miss.join(', ')); }
  try { ({ objs, rels } = await loadGraph()); metrics = await getAll('metrics'); } catch (e) { add('Data', '读取数据', 'FAIL', String(e)); }
  const badM = metrics.filter((m) => !m.key || !m.objectId || !['AVAILABLE', 'NO_DATA', 'ERROR', 'STALE', 'ESTIMATED'].includes(m.status));
  add('Data', '指标记录结构正确', badM.length ? 'FAIL' : 'PASS', badM.length ? `${badM.length} 条结构异常` : metrics.length ? `${metrics.length} 条` : '尚未刷新数据');
  const noSrc = metrics.filter((m) => m.status === 'AVAILABLE' && (!m.source || !m.retrievedAt));
  add('Data', '可用数据均有来源与获取时间', noSrc.length ? 'FAIL' : 'PASS', noSrc.map((m) => m.id).slice(0, 3).join(', '));
  const fake = metrics.filter((m) => m.status === 'NO_DATA' && (m.value !== undefined && m.value !== null));
  add('Data', '缺失数据未被填值（0 ≠ 无数据）', fake.length ? 'FAIL' : 'PASS', fake.map((m) => m.id).slice(0, 3).join(', '));
  add('Data', '数据已刷新过', metrics.length ? 'PASS' : 'WARNING', metrics.length ? '' : '尚无指标数据，请在研究页点击“刷新数据”');
  // APIs
  if (withApi) {
    try {
      const proxyTest = await fetch('/api/proxy?url=' + encodeURIComponent(CG + '/coins/markets?vs_currency=usd&ids=bitcoin&sparkline=false'), { cache:'no-store' });
      add('APIs', 'V2 Data Proxy', proxyTest.ok ? 'PASS' : 'WARNING', proxyTest.ok ? 'Worker/Pages Function 代理正常' : '代理 HTTP ' + proxyTest.status + '；可回退直连');
    } catch (e) {
      add('APIs', 'V2 Data Proxy', 'WARNING', '代理不可用：' + String(e.message || e) + '；可回退直连');
    }
    for (const [n, u] of API_TESTS) {
      try {
        const ctl = new AbortController(); setTimeout(() => ctl.abort(), 15000);
        const r = await fetch(u, { signal: ctl.signal });
        if (r.ok) add('APIs', n, 'PASS', 'HTTP ' + r.status);
        else if (r.status === 429 || r.status >= 500) add('APIs', n, 'WARNING', '外部数据源暂时不可用：HTTP ' + r.status + '；研究流程继续，不视为网站代码故障');
        else add('APIs', n, 'FAIL', 'HTTP ' + r.status);
      } catch (e) {
        add('APIs', n, 'WARNING', '外部数据源连接失败：' + String(e.message || e) + '；研究流程继续');
      }
    }
  } else add('APIs', '数据源连通性', 'WARNING', '未测试：点击“测试数据源”后才访问外部接口');
  // Identity
  const ids = objs.map((o) => o.id);
  add('Identity', 'Object ID 唯一', new Set(ids).size === ids.length ? 'PASS' : 'FAIL');
  const noChain = objs.filter((o) => !o.id || (!o.chain && o.type !== 'category'));
  add('Identity', '每个对象有 Object ID 与 Chain', noChain.length ? 'FAIL' : 'PASS', noChain.map((o) => o.id).join(', '));
  const noSym = objs.filter((o) => ['ecosystem', 'protocol', 'token'].includes(o.type) && !o.symbol);
  add('Identity', 'Symbol 已记录', noSym.length ? 'WARNING' : 'PASS', noSym.map((o) => o.id).join(', '));
  const noWeb = objs.filter((o) => ['ecosystem', 'protocol'].includes(o.type) && !/^https:\/\//.test(o.website || ''));
  add('Identity', '官方网站为 https 链接', noWeb.length ? 'WARNING' : 'PASS', noWeb.map((o) => o.id).join(', '));
  const tokNoC = objs.filter((o) => o.type === 'token' && o.id !== 'token:solana:sol' && !o.contractAddress && o.identityStatus !== 'CONFIRMED');
  add('Identity', 'Token 记录了 Contract', tokNoC.length ? 'FAIL' : 'PASS', tokNoC.length ? tokNoC.map((o) => o.id).join(', ') : objs.some((o) => o.type === 'token') ? 'Contract 缺失但身份可由其他来源确认时允许' : '暂无独立 Token 对象');
  const broken = rels.filter((x) => !ids.includes(x.from) || !ids.includes(x.to));
  add('Identity', '关系引用的对象均存在', broken.length ? 'FAIL' : 'PASS', broken.map((x) => x.id).slice(0, 2).join(', '));

  const tokenRels = rels.filter((x) => x.type === 'associated_token');
  const badTokenRels = tokenRels.filter((x) => (objs.find((o) => o.id === x.to) || {}).type !== 'token');
  add('Identity', 'Protocol / Ecosystem → Token 关联有效', badTokenRels.length ? 'FAIL' : 'PASS', badTokenRels.map((x) => x.id).slice(0, 3).join(', '));

  const jitoRel = rels.find((x) => x.from === 'protocol:solana:jito' && x.type === 'associated_token');
  const jto = jitoRel ? objs.find((o) => o.id === jitoRel.to) : null;
  add(
    'Identity',
    'Jito → JTO 关联存在',
    jitoRel && jto && jto.type === 'token' && jto.symbol === 'JTO' ? 'PASS' : 'FAIL',
    jto ? `${jto.id}｜${jto.symbol || '无 Symbol'}｜Identity=${jto.identityStatus || '未设置'}` : '未找到 Jito 关联 Token'
  );

  const confirmedTokenMissingId = objs.filter((o) => o.type === 'token' && o.identityStatus === 'CONFIRMED' && !o.gecko_id && o.id !== 'token:solana:sol');
  add('Identity', '已确认 Token 具有可追溯资产身份', confirmedTokenMissingId.length ? 'WARNING' : 'PASS', confirmedTokenMissingId.map((o) => o.id).slice(0, 3).join(', '));

  const jtoMetrics = jitoRel ? await metricsFor('protocol:solana:jito').catch(() => null) : null;
  const jtoMetricKeys = ['price', 'market_cap', 'fdv', 'volume_24h'];
  const jtoAvailable = jtoMetricKeys.filter(k => jtoMetrics?.[k]?.status === 'AVAILABLE').length;
  add(
    'Data',
    'Jito → JTO 市场数据链路',
    jtoAvailable >= 3 ? 'PASS' : (jtoAvailable > 0 ? 'WARNING' : 'FAIL'),
    `AVAILABLE ${jtoAvailable}/${jtoMetricKeys.length}`
  );

  // Research
  add('Research', '研究对象 Solana 存在', ids.includes(ECO_ID) ? 'PASS' : 'FAIL');
  const snaps = await getAll('snapshots').catch(() => []);
  const badS = snaps.filter((s) => !s.objectId || !s.date || !s.values);
  add('Research', '历史快照结构正确', badS.length ? 'FAIL' : 'PASS', `${snaps.length} 条快照（只追加，不覆盖）`);
  try { const md = await buildReport(ECO_ID); const need = ['## Identity', '## Ecosystem', '## Product', '## Users', '## Capital', '## Revenue', '## Token', '## Tokenomics', '## Risks', '## Data Gaps', '## Historical Data']; const miss = need.filter((x) => !md.includes(x)); add('Research', '报告可生成且章节完整', miss.length ? 'FAIL' : 'PASS', miss.join(', ')); } catch (e) { add('Research', '报告可生成', 'FAIL', String(e)); }
  // Deployment / V2
  add('Deployment', '运行协议', /^https?:$/.test(location.protocol) ? 'PASS' : 'WARNING', location.protocol === 'file:' ? '建议通过 Cloudflare Pages 运行 V2 API' : location.protocol);
  const scripts = [...document.scripts].map((s) => s.src).filter(Boolean);
  const ext = scripts.filter((s) => !s.startsWith(location.origin));
  add('Deployment', '前端脚本加载', ext.length ? 'WARNING' : 'PASS', ext.join(', '));
  add('Deployment', 'V2 API 路由', cloudReady ? 'PASS' : 'WARNING', cloudReady ? '/api/health 可用' : '未连接；本地回退仍可运行');
  add('Deployment', '构建 / broken import 检查', 'PASS', '源码即产物；当前页面模块已成功加载');
  try { await put('self_check_runs', { id: 'run:' + Date.now(), at: Date.now(), summary: { PASS: C.filter((c) => c.level === 'PASS').length, WARNING: C.filter((c) => c.level === 'WARNING').length, FAIL: C.filter((c) => c.level === 'FAIL').length } }); } catch { /* ignore */ }
  return C;
}
const checksHtml = (C) => ['Project', 'Data', 'APIs', 'Identity', 'Research', 'Deployment'].map((g) => `<h3>${g}</h3><div class="stack">${C.filter((c) => c.group === g).map((c) => `<div class="check"><b class="${c.level === 'PASS' ? 'pass' : c.level === 'FAIL' ? 'error' : 'warn'}">${c.level}</b><span>${esc(c.name)}${c.detail ? `<br><small class="muted">${esc(c.detail)}</small>` : ''}</span></div>`).join('')}</div>`).join('');
async function pageSelfCheck() {
  const C = await runChecks(false);
  globalThis.__selfCheck = C;
  return `<section><h1>Self Check / 系统自检</h1><p>自检验证工具链，不代表研究质量，也不是项目评分。</p><p><button class="btn" data-act="testapi">测试数据源</button> <button class="btn" data-act="copyselfcheck">Copy Self Check（复制自检结果）</button> <span id="msg" class="muted"></span></p><div id="checks">${checksHtml(C)}</div></section>`;
}

/* ===================== 事件（统一委托） ===================== */
const msg = (t) => { const m = document.querySelector('#msg'); if (m) m.textContent = t; };
async function copyText(t) {
  try { await navigator.clipboard.writeText(t); return true; } catch { /* fallback */ }
  try { const a = document.createElement('textarea'); a.value = t; a.style.position = 'fixed'; a.style.opacity = '0'; document.body.appendChild(a); a.select(); const ok = document.execCommand('copy'); a.remove(); return ok; } catch { return false; }
}
document.addEventListener('click', async (ev) => {
  const el = ev.target.closest('[data-act]');
  if (!el || el.tagName === 'SELECT' || el.type === 'checkbox') return;
  const act = el.dataset.act, id = el.dataset.id;
  try {
    if (act === 'refresh') { el.disabled = true; await refreshObject(id); }
    else if (act === 'snapshot') { const { byId } = await loadGraph(); const n = document.querySelector('#snapnote'); const s = await saveSnapshot(byId[id], n && n.value); msg(`已保存快照（${s.date}，缺失字段保持“暂无数据”）。`); }
    else if (act === 'copy') { msg((await copyText(globalThis.__report)) ? '已复制到剪贴板。' : '复制失败：请长按报告文本手动复制。'); }
    else if (act === 'copyselfcheck') {
      const C = globalThis.__selfCheck || await runChecks(false);
      const textOut = [
        '加密货币生态研究工具｜Self Check / 系统自检',
        '生成时间：' + new Date().toLocaleString('zh-CN'),
        '',
        ...C.map((c) => `${c.level}｜${c.group}｜${c.name}${c.detail ? '｜' + c.detail : ''}`)
      ].join('\n');
      msg((await copyText(textOut)) ? '自检结果已复制到剪贴板。' : '复制失败：请长按自检结果手动复制。');
    }
    else if (act === 'download') { const b = new Blob([globalThis.__report], { type: 'text/markdown' }); const a = document.createElement('a'); a.href = URL.createObjectURL(b); a.download = 'research-report.md'; a.click(); setTimeout(() => URL.revokeObjectURL(a.href), 2000); }
    else if (act === 'lookup') await doLookup();
    else if (act === 'savetoken') { await put('objects', globalThis.__lookup); el.textContent = '已保存'; el.disabled = true; searchObjs = (await loadGraph()).objs; }
    else if (act === 'testapi') { msg('测试中…'); const C = await runChecks(true); globalThis.__selfCheck = C; document.querySelector('#checks').innerHTML = checksHtml(C); msg(''); }
  } catch (e) { errLog.push(act + ': ' + (e && e.message)); msg('操作失败：' + (e && e.message)); if (el) el.disabled = false; }
});
document.addEventListener('change', async (ev) => {
  const el = ev.target.closest('[data-act]');
  if (!el) return;
  const act = el.dataset.act;
  try {
    if (act === 'status') { const r = await getResearch(el.dataset.id); r.override = el.value || null; r.updatedAt = Date.now(); await put('research', r); }
    else if (act === 'step') { const r = await getResearch(el.dataset.id); const i = +el.dataset.i; r.steps = el.checked ? [...new Set([...r.steps, i])] : r.steps.filter((x) => x !== i); r.updatedAt = Date.now(); await put('research', r); const h = el.closest('.panel').querySelector('h3'); if (h) h.textContent = `研究进度：${r.steps.length} / ${STEPS.length}`; }
    else if (act === 'histobj') { await setSetting('current', el.value); location.hash = '#history/' + encodeURIComponent(el.value); }
    else if (act === 'reportobj') { await setSetting('current', el.value); location.hash = '#report/' + encodeURIComponent(el.value); }
  } catch (e) { errLog.push(act + ': ' + (e && e.message)); }
});

if (!location.hash) location.hash = '#home';
addEventListener('hashchange', render);
render();
