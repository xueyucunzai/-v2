// 种子数据：仅包含可由官方来源确认的身份信息。不含任何市场数据。
export const ECO_ID = 'ecosystem:solana';

const S = {
  jupSite: { label: 'Jupiter 官方网站', url: 'https://jup.ag' },
  jupSwap: { label: 'Jupiter 开发者文档：Swap API', url: 'https://developers.jup.ag/docs/swap' },
  jupDao: { label: 'Jupiter 官方文档：DAO / JUP', url: 'https://docs.jup.ag/user-docs/more/dao' },
  rayDocs: { label: 'Raydium 官方文档', url: 'https://docs.raydium.io/' },
  raySite: { label: 'Raydium 官方网站', url: 'https://raydium.io' },
  rayToken: { label: 'Raydium 官方文档：RAY 代币', url: 'https://docs.raydium.io/raydium/protocol/the-ray-token' },
  jitoSite: { label: 'Jito 官方网站（Jito Foundation）', url: 'https://www.jito.network' },
  jitoIntro: { label: 'Jito 官方文档：Introduction to Jito', url: 'https://www.jito.network/docs/jitosol/introduction-to-jito/' },
  jitoMev: { label: 'Jito 官方文档：Maximum Extractable Value', url: 'https://www.jito.network/docs/jitosol/jitosol-liquid-staking/maximum-extractible-value/' },
  jitoJto: { label: 'Jito 官方文档：JTO 治理代币', url: 'https://www.jito.network/docs/governance/the-jito-governance-token-jto/' },
  sanSite: { label: 'Sanctum 官方网站', url: 'https://sanctum.so' },
  sanDocs: { label: 'Sanctum 官方文档：What is Sanctum?', url: 'https://learn.sanctum.so/docs' },
  sanCloud: { label: 'Sanctum 官方博客：$CLOUD', url: 'https://learn.sanctum.so/blog/usdcloud-genesis-mint-and-accountability' },
};

const cat = (k, name, order, identity) => ({
  id: `category:solana:${k}`, name, type: 'category', chain: 'solana', ecosystem: 'solana',
  parent_id: ECO_ID, sort_order: order, identity, data_status: 'taxonomy',
});
const proto = (k, name, symbol, identity, website, sources) => ({
  id: `protocol:solana:${k}`, name, symbol, type: 'protocol', chain: 'solana', ecosystem: 'solana',
  identity, website, sources, data_status: 'identity_only',
});

const CATS = [
  cat('dex', 'DEX', 1, 'Solana 生态分类：去中心化交易 / 交易聚合'),
  cat('liquid-staking', 'Liquid Staking', 2, 'Solana 生态分类：流动性质押'),
  cat('mev-infrastructure', 'MEV Infrastructure', 3, 'Solana 生态分类：MEV 基础设施'),
  cat('lending', 'Lending', 4, 'Solana 生态分类：借贷'),
];

const PROTOS = [
  proto('jupiter', 'Jupiter', 'JUP', 'Solana 上的 swap 聚合协议 · 治理代币 JUP', 'https://jup.ag', [S.jupSite, S.jupSwap, S.jupDao]),
  proto('raydium', 'Raydium', 'RAY', 'Solana 上的 AMM 交易协议 · 代币 RAY', 'https://raydium.io', [S.raySite, S.rayDocs, S.rayToken]),
  proto('jito', 'Jito', 'JTO', 'Solana 的 liquid staking（JitoSOL）与 MEV 基础设施 · 治理代币 JTO', 'https://www.jito.network', [S.jitoSite, S.jitoIntro, S.jitoMev, S.jitoJto]),
  proto('sanctum', 'Sanctum', 'CLOUD', 'Solana 的 liquid staking 协议 · 治理代币 CLOUD', 'https://sanctum.so', [S.sanSite, S.sanDocs, S.sanCloud]),
];

const token = (k, name, symbol, contractAddress, gecko_id, identity, sources) => ({
  id: `token:solana:${k}`, name, symbol, type: 'token', chain: 'solana', ecosystem: 'solana',
  contractAddress: contractAddress || null, contract: contractAddress || null, gecko_id: gecko_id || null,
  identitySource: sources && sources.length ? sources.map((x) => x.label).join(' · ') : '',
  identityStatus: 'CONFIRMED', identity, sources, data_status: 'identity_only',
});

const TOKENS = [
  token('sol', 'Solana', 'SOL', null, 'solana', 'Solana 原生代币 SOL · Solana Native Token', [{ label: 'Solana 官方网站', url: 'https://solana.com' }]),
  token('jto', 'Jito', 'JTO', 'jtojtomepa8beP8AuQc6eXt5FriJwfFMwQx2v2f9mCL', 'jito-governance-token', 'Jito 治理代币 JTO · Solana SPL Token', [S.jitoJto]),
  token('jup', 'Jupiter', 'JUP', null, null, 'Jupiter 治理代币 JUP · Solana SPL Token', [S.jupDao]),
  token('ray', 'Raydium', 'RAY', null, null, 'Raydium 代币 RAY · Solana SPL Token', [S.rayToken]),
  token('cloud', 'Sanctum', 'CLOUD', 'CLoUDKc4Ane7HeQcPpE3YHnznRxhMimJ4MyaUqyHFzAu', null, 'Sanctum 治理代币 CLOUD · Solana SPL Token', [S.sanCloud]),
];

const T = (k) => `token:solana:${k}`;

const rel = (from, type, to, note, sources) => ({
  id: `rel:${from}|${type}|${to}`, from, to, type, status: 'confirmed', note, sources,
});
const P = (k) => `protocol:solana:${k}`;
const C = (k) => `category:solana:${k}`;

const RELS = [
  rel(P('jupiter'), 'part_of_ecosystem', ECO_ID, '官方文档称其为 Solana 上的 Swap API；Jupiter DAO 文档称其目标是扩展 Jupiter 与 Solana', [S.jupSwap, S.jupDao]),
  rel(P('jupiter'), 'in_category', C('dex'), '官方 Swap API 文档描述：多个路由引擎竞价，提供聚合交易（swap）', [S.jupSwap]),
  rel(P('raydium'), 'part_of_ecosystem', ECO_ID, '官方文档称其链上程序部署在 Solana 上', [S.rayDocs]),
  rel(P('raydium'), 'in_category', C('dex'), '官方文档列出 AMM v4、CPMM、CLMM 等 AMM 链上程序', [S.rayDocs]),
  rel(P('jito'), 'part_of_ecosystem', ECO_ID, '官方文档称其为 Solana 的 liquid staking 服务', [S.jitoIntro]),
  rel(P('jito'), 'in_category', C('liquid-staking'), '官方文档：用户质押 SOL 获得 liquid staking 代币 JitoSOL', [S.jitoIntro]),
  rel(P('jito'), 'in_category', C('mev-infrastructure'), '官方文档：为验证者提供客户端与区块引擎拍卖机制，并把 MEV 收益分配给质押者', [S.jitoMev]),
  rel(P('sanctum'), 'part_of_ecosystem', ECO_ID, '官方文档：团队自 2021 年起在 Solana 上构建', [S.sanDocs]),
  rel(P('sanctum'), 'in_category', C('liquid-staking'), '官方文档称其为 Solana 的 liquid staking 协议', [S.sanDocs]),
  rel(ECO_ID, 'associated_token', T('sol'), 'SOL 是 Solana 原生代币', [{ label: 'Solana 官方网站', url: 'https://solana.com' }]),
  rel(P('jito'), 'associated_token', T('jto'), 'JTO 是 Jito Network 的治理代币', [S.jitoJto]),
  rel(P('jupiter'), 'associated_token', T('jup'), 'JUP 是 Jupiter 治理代币', [S.jupDao]),
  rel(P('raydium'), 'associated_token', T('ray'), 'RAY 是 Raydium 代币', [S.rayToken]),
  rel(P('sanctum'), 'associated_token', T('cloud'), 'CLOUD 是 Sanctum 治理代币', [S.sanCloud]),
];

const ECO = {
  id: ECO_ID, name: 'Solana', symbol: 'SOL', type: 'ecosystem', chain: 'solana', ecosystem: 'solana',
  identity: 'Solana 公链网络 · 原生代币 SOL', website: 'https://solana.com',
  gecko_id: 'solana',
  sources: [
    { label: 'Solana 官方网站', url: 'https://solana.com' },
    { label: 'Solana Foundation 官方网站', url: 'https://solana.org' },
  ],
  data_status: 'identity_only',
};

export const SEED_OBJECTS = [ECO, ...CATS, ...PROTOS, ...TOKENS];
export const SEED_RELS = RELS;
