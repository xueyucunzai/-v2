# 加密货币生态研究工具 V2

## 架构

- Cloudflare Pages：前端
- Cloudflare Pages Functions / Workers：`/api/*`
- Cloudflare D1：研究数据与历史快照
- DeFiLlama / CoinGecko / DexScreener：公开数据源
- IndexedDB：后端不可用时的本地安全回退

## V2 数据流

浏览器 → Pages → `/api/*` → D1

外部数据源仍由前端当前的数据采集层访问；后续可继续把数据采集全部迁入 Worker。

## 一次性部署

1. 在 Cloudflare 创建 D1 数据库：`crypto-ecosystem-research`
2. 执行 `schema.sql`
3. 在 `wrangler.toml` 填入真实 `database_id`
4. 通过 Cloudflare Pages/Functions 或 Wrangler 部署本项目。
5. 打开网站后，Self Check 应看到：
   - V2 Backend / D1：PASS
   - Storage：D1
6. 第一次打开时，如果浏览器已有 V1 IndexedDB 数据，V2 会尝试自动迁移到 D1。

## 重要

当前 V2 API 是个人研究工具的第一版数据层，没有加入账号系统。
如果网站公开给不认识的人使用，下一阶段应增加 Cloudflare Access 或其他认证/写入保护。

## 数据原则

- `NO_DATA` 不等于 0
- 不估算未知数据
- Token Identity 优先 Chain + Contract
- Protocol 本身不要求 Contract
- Historical Snapshot 只追加、不覆盖
- 每条可用指标保留 source / retrievedAt
