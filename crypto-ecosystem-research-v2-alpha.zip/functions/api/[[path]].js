/**
 * 加密货币生态研究工具 V2
 * Cloudflare Pages Functions / Workers + D1
 *
 * Routes:
 *   GET  /api/health
 *   GET  /api/store/:store
 *   GET  /api/store/:store/:id
 *   PUT  /api/store/:store          { item }
 *   POST /api/migrate                { stores: {store:[items]} }
 */
const ALLOWED_STORES = new Set([
  'objects','relationships','sources','metrics','data_records','research',
  'branches','observations','hypotheses','evidence','findings','snapshots',
  'events','settings','self_check_runs','ai_action_logs'
]);

function json(data, status = 200) {
  return new Response(JSON.stringify(data), {
    status,
    headers: {
      'content-type': 'application/json; charset=utf-8',
      'cache-control': 'no-store'
    }
  });
}

function bad(message, status = 400) {
  return json({ ok:false, error:message }, status);
}

function storeName(raw) {
  const s = decodeURIComponent(raw || '');
  return ALLOWED_STORES.has(s) ? s : null;
}

async function all(db, store) {
  const rows = await db.prepare(
    'SELECT id, data, updated_at FROM records WHERE store = ? ORDER BY updated_at DESC'
  ).bind(store).all();
  return rows.results.map(r => ({ ...JSON.parse(r.data), id: r.id }));
}

async function one(db, store, id) {
  const row = await db.prepare(
    'SELECT id, data, updated_at FROM records WHERE store = ? AND id = ? LIMIT 1'
  ).bind(store, id).first();
  return row ? { ...JSON.parse(row.data), id: row.id } : null;
}

async function save(db, store, item) {
  if (!item || item.id === undefined || item.id === null || item.id === '') {
    throw new Error('item.id required');
  }
  const id = String(item.id);
  const now = Date.now();
  await db.prepare(`
    INSERT INTO records(store,id,data,updated_at)
    VALUES(?,?,?,?)
    ON CONFLICT(store,id) DO UPDATE SET
      data=excluded.data,
      updated_at=excluded.updated_at
  `).bind(store, id, JSON.stringify(item), now).run();
  return { ...item, id };
}

async function migrate(db, stores) {
  let count = 0;
  for (const [rawStore, items] of Object.entries(stores || {})) {
    const store = storeName(rawStore);
    if (!store || !Array.isArray(items)) continue;
    for (const item of items) {
      await save(db, store, item);
      count++;
    }
  }
  return count;
}

export async function onRequest(context) {
  const { request, env, params } = context;
  const db = env.DB;
  if (!db) return bad('D1 binding DB 未配置', 503);

  const parts = Array.isArray(params?.path) ? params.path : String(params?.path || '').split('/').filter(Boolean);
  const route = parts.map(x => decodeURIComponent(x));

  try {
    if (request.method === 'GET' && route[0] === 'health') {
      return json({
        ok: true,
        version: 'v2',
        storage: 'D1',
        runtime: 'Cloudflare Pages Functions / Workers',
        time: Date.now()
      });
    }

    if (request.method === 'GET' && route[0] === 'proxy') {
      const raw = new URL(request.url).searchParams.get('url');
      if (!raw) return bad('url required');
      let target;
      try { target = new URL(raw); } catch { return bad('invalid url'); }
      const allowed = new Set([
        'api.coingecko.com',
        'api.llama.fi',
        'stablecoins.llama.fi',
        'api.dexscreener.com'
      ]);
      if (target.protocol !== 'https:' || !allowed.has(target.hostname)) {
        return bad('data source not allowed', 403);
      }
      const upstream = await fetch(target.toString(), {
        headers: { 'accept': 'application/json' },
        cf: { cacheTtl: 60, cacheEverything: true }
      });
      const body = await upstream.text();
      return new Response(body, {
        status: upstream.status,
        headers: {
          'content-type': upstream.headers.get('content-type') || 'application/json',
          'cache-control': 'public, max-age=60'
        }
      });
    }

    if (request.method === 'GET' && route[0] === 'store') {
      const store = storeName(route[1]);
      if (!store) return bad('未知 store');
      if (route.length >= 3) {
        return json({ ok:true, item:await one(db, store, route.slice(2).join('/')) });
      }
      return json({ ok:true, items:await all(db, store) });
    }

    if (request.method === 'PUT' && route[0] === 'store') {
      const store = storeName(route[1]);
      if (!store) return bad('未知 store');
      const body = await request.json();
      const item = await save(db, store, body.item);
      return json({ ok:true, item });
    }

    if (request.method === 'POST' && route[0] === 'migrate') {
      const body = await request.json();
      const count = await migrate(db, body.stores);
      return json({ ok:true, migrated:count });
    }

    return bad('Not Found', 404);
  } catch (e) {
    return json({ ok:false, error:String(e?.message || e) }, 500);
  }
}
