-- 加密货币生态研究工具 V2
-- D1: 统一保存研究对象、指标、关系和历史快照。
CREATE TABLE IF NOT EXISTS records (
  store TEXT NOT NULL,
  id TEXT NOT NULL,
  data TEXT NOT NULL,
  updated_at INTEGER NOT NULL,
  PRIMARY KEY (store, id)
);

CREATE INDEX IF NOT EXISTS idx_records_store_updated
ON records(store, updated_at DESC);

CREATE INDEX IF NOT EXISTS idx_records_updated
ON records(updated_at DESC);
